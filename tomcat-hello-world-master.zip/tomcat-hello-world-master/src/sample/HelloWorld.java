package sample;

/**
 * Created by chamilad on 9/5/14.
 */
public class HelloWorld {

    public static String getMessage() {
        return "Hello World Tomcat!!";
    }
}
